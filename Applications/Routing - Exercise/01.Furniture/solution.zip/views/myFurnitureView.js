import { myFurniture } from '../api/data.js';
import { html, until } from '/lib.js';

const furnitureTemplate = x => html`
  <div class="col-md-4">
    <div class="card text-white bg-primary">
      <div class="card-body">
        <img src=${x.img} />
        <p>${x.description}</p>
        <footer>
          <p>Price: <span>${x.price} $</span></p>
        </footer>
        <div>
          <a href="/details/${x._id}" class="btn btn-info">Details</a>
        </div>
      </div>
    </div>
  </div>
`;

const myFurnitureTemplate = (promise, id) => html`
  <div class="row space-top">
    <div class="col-md-12">
      <h1>My Furniture</h1>
      <p>This is a list of your publications.</p>
    </div>
  </div>
  <div class="row space-top">
    <!-- user furniture goes here -->
    ${until(promise(id), html`<p>Loading my furniture...</p>`)}
  </div>
`;

export function myFurnitureView(ctx) {
  const user = ctx.getUserData();
  ctx.updateUserNav();
  ctx.render(myFurnitureTemplate(loadUserFurniture, user.id));
}

async function loadUserFurniture(userId) {
  const data = await myFurniture(userId);
  return data.map(furnitureTemplate);
}
