import { html } from '/lib.js';

const townsTemplate = town => html` <li>${town}</li> `;

export default townsTemplate;
