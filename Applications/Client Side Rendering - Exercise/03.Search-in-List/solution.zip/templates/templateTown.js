import { html } from '/lib.js';

const townTamplate = town => html`<li>${town}</li>`;

export default townTamplate;
