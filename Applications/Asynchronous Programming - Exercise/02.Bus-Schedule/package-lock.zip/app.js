function solve() {
  let baseUrl = 'http://localhost:3030/jsonstore/bus/schedule/';
  const infoBox = document.querySelector('.info');
  const arriveBtn = document.getElementById('arrive');
  const departBtn = document.getElementById('depart');

  let stopId = 'depot';

  const endpoints = {
    catalog: (id) => `${baseUrl}${id}`,
  };

  function disabledCommander() {
    return {
      enable: (btn) => btn.removeAttribute('disabled'),
      disable: (btn) => btn.setAttribute('disabled', true),
    };
  }

  function disabledAttributeHandler(buttonsInfo) {
    const state = disabledCommander();

    Object.entries(buttonsInfo).forEach((entry) => {
      const [command, btnName] = entry;
      state[command](btnName);
    });
  }

  function showInfo(infoBoxContent, buttonsInfo) {
    fetch(endpoints.catalog(stopId))
      .then((res) => res.json())
      .then((result) => {
        const { name: busStopName, next: nextStop } = result;
        stopId = nextStop;

        infoBox.textContent = `${infoBoxContent} ${busStopName}`;
        disabledAttributeHandler(buttonsInfo);
      });
  }

  function depart() {
    showInfo('Next Stop', { enable: arriveBtn, disable: departBtn });
  }

  function arrive() {
    showInfo('Arriving at', { enable: departBtn, disable: arriveBtn });
  }

  return {
    depart,
    arrive,
  };
}

let result = solve();
